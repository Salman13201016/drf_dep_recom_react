from django.apps import AppConfig


class HospitalMapAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hospital_map_app'
